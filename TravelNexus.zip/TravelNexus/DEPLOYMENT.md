# Deploying TravelHub to Railway

Deploy your travel booking website to Railway.app with automatic database provisioning.

## Quick Start

### 1. Connect Repository to Railway

1. Visit [railway.app](https://railway.app) and create an account
2. Click "New Project" → "Deploy from GitHub repo" 
3. Select your TravelHub repository
4. Railway automatically detects the Node.js project

### 2. Add PostgreSQL Database

1. In your Railway project dashboard, click "New Service"
2. Select "Database" → "Add PostgreSQL"
3. Railway automatically connects the database and sets `DATABASE_URL`

### 3. Deploy

Railway automatically:
- Installs dependencies with `npm ci`
- Builds frontend and backend with `npm run build`
- Pushes database schema with Drizzle
- Seeds database with travel data
- Starts the application with `npm start`

Your travel site will be live at `https://your-project.railway.app`

## Configuration Files

Railway deployment is optimized with these files:

- **railway.toml** - Deployment settings and database configuration
- **nixpacks.toml** - Build phases optimized for Node.js 20
- **Procfile** - Web service process definition  
- **.railwayignore** - Excludes development files from deployment

## Automatic Database Setup

Railway automatically:
1. Provisions PostgreSQL database with SSL
2. Sets DATABASE_URL environment variable
3. Runs schema migrations via Drizzle
4. Seeds database with travel data on first deployment

## Build Process

Railway executes these phases automatically:

1. **Setup**: Provisions Node.js 20 and npm
2. **Install**: Runs `npm ci` for dependencies
3. **Build**: Compiles frontend (Vite) and backend (esbuild)
4. **Deploy**: Pushes database schema and seeds travel data
5. **Start**: Launches the Express server on Railway's assigned port

## Environment Variables

Railway automatically provides:
- `DATABASE_URL` - PostgreSQL connection string
- `PORT` - Dynamic port assignment
- `NODE_ENV=production` - Runtime environment

No manual configuration required.

## Post-Deployment

After successful deployment:
- Database schema is created automatically
- Travel data (destinations, hotels, flights, packages) is seeded
- Health checks ensure service availability
- Logs are available in Railway dashboard

## Custom Domain (Optional)

1. In Railway project settings, go to "Domains"
2. Add your custom domain
3. Update DNS records as instructed by Railway

## Monitoring & Scaling

Railway provides built-in:
- Real-time deployment logs
- Resource usage monitoring
- Automatic scaling and health checks
- Zero-downtime deployments

Your travel booking platform is production-ready on Railway's infrastructure.