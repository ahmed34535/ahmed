#!/bin/bash

# Railway Deployment Script for Travel Booking App
# Run this after uploading to GitHub

echo "=== Railway Deployment Guide ==="
echo ""
echo "1. Your GitHub repository: https://github.com/ahmed34535/ahmed"
echo "2. Go to railway.app and sign in"
echo "3. Create new project from GitHub repo"
echo "4. Add environment variable: DATABASE_URL"
echo "5. Railway will automatically:"
echo "   - Detect Node.js project"
echo "   - Run npm ci"
echo "   - Run npm run build"
echo "   - Run npm start"
echo ""
echo "Build artifacts ready:"
echo "- Frontend: 361KB optimized"
echo "- Backend: 14KB compiled"
echo ""
echo "Expected deployment time: ~5 minutes"
echo "=== Ready for Railway deployment ==="