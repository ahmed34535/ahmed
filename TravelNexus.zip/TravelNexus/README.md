# TravelHub - Travel Booking Platform

A modern travel booking website similar to Expedia, built with React, TypeScript, and Express.js.

## Features

- **Flight Search**: Search and compare flights with filtering and sorting
- **Hotel Booking**: Browse hotels with amenities, ratings, and pricing
- **Destinations**: Explore popular travel destinations worldwide
- **Travel Packages**: Complete vacation packages with everything included
- **Responsive Design**: Works perfectly on desktop, tablet, and mobile

## Tech Stack

### Frontend
- React 18 with TypeScript
- Vite for fast development and builds
- Tailwind CSS for styling
- shadcn/ui component library
- TanStack Query for data fetching
- Wouter for client-side routing

### Backend
- Node.js with Express.js
- TypeScript for type safety
- PostgreSQL database with Drizzle ORM
- Neon serverless database integration
- RESTful API endpoints
- Production-ready server configuration

## Getting Started

### Development

1. Clone the repository
2. Install dependencies:
   ```bash
   npm install
   ```
3. Start the development server:
   ```bash
   npm run dev
   ```
4. Open http://localhost:5000 in your browser

### Production Build

1. Run pre-deployment verification:
   ```bash
   ./PRE_DEPLOYMENT_TEST.sh
   ```
2. Or manually build and start:
   ```bash
   npm run build
   npm run start
   ```

## Railway Deployment

Deploy in 3 simple steps:

1. **Connect**: Link your GitHub repository to Railway
2. **Database**: Add PostgreSQL service in Railway dashboard  
3. **Deploy**: Railway automatically builds and deploys your travel booking site

The application includes Railway-optimized configuration with automatic database migrations and seeding.

### Environment Variables

The application requires a PostgreSQL database. Railway automatically provisions this:

- `DATABASE_URL` - PostgreSQL connection string (automatically set by Railway)

For local development, you'll need to set up a PostgreSQL database and configure the DATABASE_URL.

## API Endpoints

- `GET /api/destinations` - List all destinations
- `GET /api/destinations/featured` - Featured destinations
- `GET /api/hotels` - Search hotels (supports location filtering)
- `GET /api/flights` - Search flights (supports origin/destination filtering)
- `GET /api/packages` - List travel packages
- `GET /api/packages/featured` - Featured packages

## Project Structure

```
├── client/          # React frontend
│   ├── src/
│   │   ├── components/  # Reusable UI components
│   │   ├── pages/       # Application pages
│   │   └── lib/         # Utilities and configuration
├── server/          # Express.js backend
│   ├── index.ts     # Server entry point
│   ├── routes.ts    # API route handlers
│   └── storage.ts   # Data storage layer
├── shared/          # Shared TypeScript schemas
└── railway.toml     # Railway deployment configuration
```

## License

MIT License - see LICENSE file for details