#!/bin/bash
# Pre-deployment verification script for TravelHub

echo "🚀 TravelHub Pre-Deployment Verification"
echo "========================================"

# Check Node.js version
echo "📋 Checking Node.js version..."
node --version

# Install dependencies
echo "📦 Installing dependencies..."
npm ci

# Build application
echo "🔨 Building application..."
npm run build

if [ $? -ne 0 ]; then
    echo "❌ Build failed!"
    exit 1
fi

echo "✅ Build successful"

# Check database connection
echo "🗄️  Checking database connection..."
node -e "
import('./server/db.js').then(({ db }) => {
  console.log('✅ Database connection successful');
}).catch(err => {
  console.error('❌ Database connection failed:', err.message);
  process.exit(1);
});
"

# Start server for testing
echo "🌐 Starting server for health check..."
npm start &
SERVER_PID=$!

# Wait for server to start
sleep 5

# Health check
echo "🏥 Running health checks..."
curl -s http://localhost:5000/api/destinations/featured > /dev/null
if [ $? -eq 0 ]; then
    echo "✅ API endpoints responding"
else
    echo "❌ API health check failed"
    kill $SERVER_PID
    exit 1
fi

# Stop test server
kill $SERVER_PID

echo ""
echo "🎉 All pre-deployment checks passed!"
echo "Ready for Railway deployment"