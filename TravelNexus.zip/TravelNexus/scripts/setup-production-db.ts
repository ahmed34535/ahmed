// Simplified Railway database setup
import { seedDatabase } from './seed-database.js';

async function setupDatabase() {
  try {
    console.log("Railway: Setting up database...");
    
    const { db } = await import("../server/db.js");
    const { destinations } = await import("../shared/schema.js");
    
    // Quick check if database needs seeding
    const existing = await db.select().from(destinations).limit(1);
    
    if (existing.length === 0) {
      console.log("Railway: Seeding database...");
      await seedDatabase();
      console.log("Railway: Database seeded successfully");
    } else {
      console.log("Railway: Database already seeded");
    }
  } catch (error) {
    console.error("Railway: Database setup error:", error);
    // Continue deployment even if seeding fails
  }
}

setupDatabase();