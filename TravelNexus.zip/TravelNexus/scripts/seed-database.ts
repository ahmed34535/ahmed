import { db } from "../server/db";
import { destinations, hotels, flights, packages } from "@shared/schema";

async function seedDatabase() {
  console.log("Seeding database with travel data...");

  try {
    // Clear existing data
    await db.delete(destinations);
    await db.delete(hotels);
    await db.delete(flights);
    await db.delete(packages);

    // Seed destinations
    const destinationData = [
      {
        name: "Paris, France",
        country: "France",
        description: "The City of Light awaits with iconic landmarks and romance",
        imageUrl: "https://images.unsplash.com/photo-1502602898536-47ad22581b52?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        priceFrom: "599",
        rating: "4.8",
        featured: true,
      },
      {
        name: "Tokyo, Japan",
        country: "Japan",
        description: "Experience the perfect blend of tradition and innovation",
        imageUrl: "https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        priceFrom: "899",
        rating: "4.9",
        featured: true,
      },
      {
        name: "Santorini, Greece",
        country: "Greece",
        description: "Stunning sunsets and pristine Mediterranean beauty",
        imageUrl: "https://images.unsplash.com/photo-1570077188670-e3a8d69ac5ff?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        priceFrom: "749",
        rating: "4.7",
        featured: true,
      },
      {
        name: "New York City, USA",
        country: "USA",
        description: "The city that never sleeps with endless possibilities",
        imageUrl: "https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        priceFrom: "299",
        rating: "4.6",
        featured: true,
      },
      {
        name: "Bali, Indonesia",
        country: "Indonesia",
        description: "Tropical paradise with rich culture and natural beauty",
        imageUrl: "https://images.unsplash.com/photo-1518548419970-58e3b4079ab2?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        priceFrom: "649",
        rating: "4.8",
        featured: true,
      },
      {
        name: "Dubai, UAE",
        country: "UAE",
        description: "Luxury destination with modern marvels and desert adventures",
        imageUrl: "https://images.unsplash.com/photo-1512453979798-5ea266f8880c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        priceFrom: "799",
        rating: "4.9",
        featured: true,
      },
    ];

    await db.insert(destinations).values(destinationData);
    console.log("✓ Destinations seeded");

    // Seed hotels
    const hotelData = [
      {
        name: "The Grand Plaza Hotel",
        location: "Manhattan, New York",
        description: "Luxury hotel in the heart of Times Square",
        imageUrl: "https://images.unsplash.com/photo-1578683010236-d716f9a3f461?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        pricePerNight: "199",
        rating: "4.8",
        amenities: ["Free WiFi", "Fitness Center", "Pool", "Restaurant"],
        distanceFromCenter: "0.2 miles from Times Square",
      },
      {
        name: "Boutique Riverside Inn",
        location: "Downtown Paris",
        description: "Charming boutique hotel near the Louvre",
        imageUrl: "https://images.unsplash.com/photo-1566073771259-6a8506099945?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        pricePerNight: "159",
        rating: "4.6",
        amenities: ["Free WiFi", "Concierge", "Room Service"],
        distanceFromCenter: "0.5 miles from Louvre",
      },
      {
        name: "Ocean View Resort",
        location: "Santorini, Greece",
        description: "Beachfront resort with stunning ocean views",
        imageUrl: "https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        pricePerNight: "299",
        rating: "4.9",
        amenities: ["Private Beach", "Spa", "Pool", "Restaurant"],
        distanceFromCenter: "Beachfront location",
      },
      {
        name: "Executive Business Hotel",
        location: "Tokyo Business District",
        description: "Modern business hotel with excellent connectivity",
        imageUrl: "https://images.unsplash.com/photo-1584132967334-10e028bd69f7?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        pricePerNight: "179",
        rating: "4.5",
        amenities: ["Business Center", "Free WiFi", "Fitness Center"],
        distanceFromCenter: "Near subway",
      },
      {
        name: "Skyline Luxury Suites",
        location: "Dubai Marina",
        description: "Luxury suites with panoramic city views",
        imageUrl: "https://images.unsplash.com/photo-1571003123894-1f0594d2b5d9?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        pricePerNight: "399",
        rating: "4.9",
        amenities: ["Luxury Spa", "Infinity Pool", "Butler Service"],
        distanceFromCenter: "Burj Khalifa views",
      },
      {
        name: "Tropical Paradise Lodge",
        location: "Bali Beach Resort",
        description: "Eco-friendly resort with private beach access",
        imageUrl: "https://images.unsplash.com/photo-1571003123894-1f0594d2b5d9?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        pricePerNight: "249",
        rating: "4.7",
        amenities: ["Private Beach", "Yoga Classes", "Organic Restaurant"],
        distanceFromCenter: "Private beach access",
      },
    ];

    await db.insert(hotels).values(hotelData);
    console.log("✓ Hotels seeded");

    // Seed flights
    const flightData = [
      {
        airline: "American Airlines",
        flightNumber: "AA101",
        departureAirport: "JFK",
        arrivalAirport: "LHR",
        departureTime: "8:00 AM",
        arrivalTime: "2:00 PM",
        duration: "8h 00m",
        price: "599",
        stops: 0,
        aircraft: "Boeing 777",
        class: "Economy",
      },
      {
        airline: "Delta Airlines",
        flightNumber: "DL205",
        departureAirport: "JFK",
        arrivalAirport: "LHR",
        departureTime: "11:30 AM",
        arrivalTime: "6:45 PM",
        duration: "9h 15m",
        price: "489",
        stops: 1,
        aircraft: "Airbus A330",
        class: "Economy",
      },
      {
        airline: "British Airways",
        flightNumber: "BA189",
        departureAirport: "LHR",
        arrivalAirport: "JFK",
        departureTime: "10:15 AM",
        arrivalTime: "1:30 PM",
        duration: "8h 15m",
        price: "629",
        stops: 0,
        aircraft: "Boeing 787",
        class: "Economy",
      },
      {
        airline: "Emirates",
        flightNumber: "EK203",
        departureAirport: "JFK",
        arrivalAirport: "DXB",
        departureTime: "1:00 AM",
        arrivalTime: "10:30 PM",
        duration: "12h 30m",
        price: "899",
        stops: 0,
        aircraft: "Airbus A380",
        class: "Business",
      },
    ];

    await db.insert(flights).values(flightData);
    console.log("✓ Flights seeded");

    // Seed packages
    const packageData = [
      {
        name: "Caribbean Paradise",
        destination: "Caribbean",
        description: "7 days of tropical bliss with flights and hotel included",
        imageUrl: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250",
        duration: "7 days",
        price: "1299",
        rating: "4.8",
        includes: ["Flights", "Hotel", "Breakfast", "Airport Transfers"],
        featured: true,
      },
      {
        name: "European Explorer",
        destination: "Europe",
        description: "10-day multi-city European adventure",
        imageUrl: "https://images.unsplash.com/photo-1467269204594-9661b134dd2b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250",
        duration: "10 days",
        price: "2199",
        rating: "4.9",
        includes: ["Flights", "Hotels", "Guided Tours", "Transportation"],
        featured: true,
      },
      {
        name: "Asian Adventure",
        destination: "Asia",
        description: "12-day guided tour through Asia's highlights",
        imageUrl: "https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
        duration: "12 days",
        price: "1899",
        rating: "4.6",
        includes: ["Flights", "Hotels", "Guided Tours", "Some Meals"],
        featured: true,
      },
      {
        name: "Safari Explorer",
        destination: "Africa",
        description: "8-day wildlife safari adventure",
        imageUrl: "https://images.unsplash.com/photo-1516426122078-c23e76319801?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250",
        duration: "8 days",
        price: "3499",
        rating: "4.9",
        includes: ["Flights", "Safari Lodge", "Game Drives", "All Meals"],
        featured: true,
      },
    ];

    await db.insert(packages).values(packageData);
    console.log("✓ Packages seeded");

    console.log("Database seeding completed successfully!");
  } catch (error) {
    console.error("Error seeding database:", error);
    throw error;
  }
}

// Run the seed function if this file is executed directly
if (import.meta.url === `file://${process.argv[1]}`) {
  seedDatabase()
    .then(() => process.exit(0))
    .catch(() => process.exit(1));
}

export { seedDatabase };