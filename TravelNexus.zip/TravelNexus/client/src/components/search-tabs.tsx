import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import { Plane, Hotel, Package } from "lucide-react";
import { useLocation } from "wouter";

interface SearchTabsProps {
  onFlightSearch?: (data: FlightSearchData) => void;
  onHotelSearch?: (data: HotelSearchData) => void;
  onPackageSearch?: (data: PackageSearchData) => void;
}

interface FlightSearchData {
  from: string;
  to: string;
  departure: string;
  return: string;
  passengers: string;
  class: string;
}

interface HotelSearchData {
  location: string;
  checkin: string;
  checkout: string;
  guests: string;
}

interface PackageSearchData {
  destination: string;
  departure: string;
  duration: string;
  travelers: string;
}

export default function SearchTabs({ onFlightSearch, onHotelSearch, onPackageSearch }: SearchTabsProps) {
  const [, setLocation] = useLocation();
  const [flightData, setFlightData] = useState<FlightSearchData>({
    from: "",
    to: "",
    departure: "",
    return: "",
    passengers: "1",
    class: "Economy"
  });

  const [hotelData, setHotelData] = useState<HotelSearchData>({
    location: "",
    checkin: "",
    checkout: "",
    guests: "1"
  });

  const [packageData, setPackageData] = useState<PackageSearchData>({
    destination: "",
    departure: "",
    duration: "7",
    travelers: "1"
  });

  const handleFlightSearch = () => {
    if (onFlightSearch) {
      onFlightSearch(flightData);
    } else {
      const searchParams = new URLSearchParams({
        from: flightData.from,
        to: flightData.to,
        departure: flightData.departure,
        return: flightData.return,
      });
      setLocation(`/flights?${searchParams.toString()}`);
    }
  };

  const handleHotelSearch = () => {
    if (onHotelSearch) {
      onHotelSearch(hotelData);
    } else {
      const searchParams = new URLSearchParams({
        location: hotelData.location,
        checkin: hotelData.checkin,
        checkout: hotelData.checkout,
      });
      setLocation(`/hotels?${searchParams.toString()}`);
    }
  };

  const handlePackageSearch = () => {
    if (onPackageSearch) {
      onPackageSearch(packageData);
    } else {
      setLocation('/packages');
    }
  };

  return (
    <Card className="bg-white rounded-lg shadow-xl max-w-4xl mx-auto">
      <CardContent className="p-6">
        <Tabs defaultValue="flights" className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-6 bg-gray-100 p-1 rounded-lg">
            <TabsTrigger 
              value="flights" 
              className="flex items-center py-3 px-4 data-[state=active]:bg-white data-[state=active]:text-travel-blue data-[state=active]:shadow-sm"
            >
              <Plane className="h-4 w-4 mr-2" />
              Flights
            </TabsTrigger>
            <TabsTrigger 
              value="hotels"
              className="flex items-center py-3 px-4 data-[state=active]:bg-white data-[state=active]:text-travel-blue data-[state=active]:shadow-sm"
            >
              <Hotel className="h-4 w-4 mr-2" />
              Hotels
            </TabsTrigger>
            <TabsTrigger 
              value="packages"
              className="flex items-center py-3 px-4 data-[state=active]:bg-white data-[state=active]:text-travel-blue data-[state=active]:shadow-sm"
            >
              <Package className="h-4 w-4 mr-2" />
              Packages
            </TabsTrigger>
          </TabsList>

          <TabsContent value="flights">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
              <div>
                <Label className="block text-sm font-medium text-gray-700 mb-1">From</Label>
                <Input
                  placeholder="City or airport"
                  value={flightData.from}
                  onChange={(e) => setFlightData({...flightData, from: e.target.value})}
                  className="w-full focus:ring-2 focus:ring-travel-blue focus:border-transparent"
                />
              </div>
              <div>
                <Label className="block text-sm font-medium text-gray-700 mb-1">To</Label>
                <Input
                  placeholder="City or airport"
                  value={flightData.to}
                  onChange={(e) => setFlightData({...flightData, to: e.target.value})}
                  className="w-full focus:ring-2 focus:ring-travel-blue focus:border-transparent"
                />
              </div>
              <div>
                <Label className="block text-sm font-medium text-gray-700 mb-1">Departure</Label>
                <Input
                  type="date"
                  value={flightData.departure}
                  onChange={(e) => setFlightData({...flightData, departure: e.target.value})}
                  className="w-full focus:ring-2 focus:ring-travel-blue focus:border-transparent"
                />
              </div>
              <div>
                <Label className="block text-sm font-medium text-gray-700 mb-1">Return</Label>
                <Input
                  type="date"
                  value={flightData.return}
                  onChange={(e) => setFlightData({...flightData, return: e.target.value})}
                  className="w-full focus:ring-2 focus:ring-travel-blue focus:border-transparent"
                />
              </div>
            </div>
            <div className="flex justify-between items-center">
              <div className="flex items-center space-x-4">
                <Select value={flightData.passengers} onValueChange={(value) => setFlightData({...flightData, passengers: value})}>
                  <SelectTrigger className="w-[140px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">1 Adult</SelectItem>
                    <SelectItem value="2">2 Adults</SelectItem>
                    <SelectItem value="3">3+ Adults</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={flightData.class} onValueChange={(value) => setFlightData({...flightData, class: value})}>
                  <SelectTrigger className="w-[140px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Economy">Economy</SelectItem>
                    <SelectItem value="Business">Business</SelectItem>
                    <SelectItem value="First">First Class</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button 
                onClick={handleFlightSearch}
                className="bg-travel-orange text-white px-8 py-3 hover:bg-orange-600 transition-colors"
              >
                Search Flights
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="hotels">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
              <div>
                <Label className="block text-sm font-medium text-gray-700 mb-1">Location</Label>
                <Input
                  placeholder="City or hotel name"
                  value={hotelData.location}
                  onChange={(e) => setHotelData({...hotelData, location: e.target.value})}
                  className="w-full focus:ring-2 focus:ring-travel-blue focus:border-transparent"
                />
              </div>
              <div>
                <Label className="block text-sm font-medium text-gray-700 mb-1">Check-in</Label>
                <Input
                  type="date"
                  value={hotelData.checkin}
                  onChange={(e) => setHotelData({...hotelData, checkin: e.target.value})}
                  className="w-full focus:ring-2 focus:ring-travel-blue focus:border-transparent"
                />
              </div>
              <div>
                <Label className="block text-sm font-medium text-gray-700 mb-1">Check-out</Label>
                <Input
                  type="date"
                  value={hotelData.checkout}
                  onChange={(e) => setHotelData({...hotelData, checkout: e.target.value})}
                  className="w-full focus:ring-2 focus:ring-travel-blue focus:border-transparent"
                />
              </div>
              <div>
                <Label className="block text-sm font-medium text-gray-700 mb-1">Guests</Label>
                <Select value={hotelData.guests} onValueChange={(value) => setHotelData({...hotelData, guests: value})}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">1 Guest</SelectItem>
                    <SelectItem value="2">2 Guests</SelectItem>
                    <SelectItem value="3">3+ Guests</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="flex justify-end">
              <Button 
                onClick={handleHotelSearch}
                className="bg-travel-orange text-white px-8 py-3 hover:bg-orange-600 transition-colors"
              >
                Search Hotels
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="packages">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
              <div>
                <Label className="block text-sm font-medium text-gray-700 mb-1">Destination</Label>
                <Input
                  placeholder="Where do you want to go?"
                  value={packageData.destination}
                  onChange={(e) => setPackageData({...packageData, destination: e.target.value})}
                  className="w-full focus:ring-2 focus:ring-travel-blue focus:border-transparent"
                />
              </div>
              <div>
                <Label className="block text-sm font-medium text-gray-700 mb-1">Departure</Label>
                <Input
                  type="date"
                  value={packageData.departure}
                  onChange={(e) => setPackageData({...packageData, departure: e.target.value})}
                  className="w-full focus:ring-2 focus:ring-travel-blue focus:border-transparent"
                />
              </div>
              <div>
                <Label className="block text-sm font-medium text-gray-700 mb-1">Duration</Label>
                <Select value={packageData.duration} onValueChange={(value) => setPackageData({...packageData, duration: value})}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="3">3 days</SelectItem>
                    <SelectItem value="7">7 days</SelectItem>
                    <SelectItem value="10">10 days</SelectItem>
                    <SelectItem value="14">14 days</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="block text-sm font-medium text-gray-700 mb-1">Travelers</Label>
                <Select value={packageData.travelers} onValueChange={(value) => setPackageData({...packageData, travelers: value})}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">1 Traveler</SelectItem>
                    <SelectItem value="2">2 Travelers</SelectItem>
                    <SelectItem value="3">3+ Travelers</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="flex justify-end">
              <Button 
                onClick={handlePackageSearch}
                className="bg-travel-orange text-white px-8 py-3 hover:bg-orange-600 transition-colors"
              >
                Search Packages
              </Button>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}
