import { useQuery } from "@tanstack/react-query";
import Header from "@/components/header";
import SearchTabs from "@/components/search-tabs";
import DestinationCard from "@/components/destination-card";
import HotelCard from "@/components/hotel-card";
import PackageCard from "@/components/package-card";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Shield, Star, Headphones, Users, Plane, Hotel as HotelIcon } from "lucide-react";
import type { Destination, Hotel, Package } from "@shared/schema";

export default function Home() {
  const { data: destinations = [] } = useQuery<Destination[]>({
    queryKey: ["/api/destinations/featured"],
  });

  const { data: hotels = [] } = useQuery<Hotel[]>({
    queryKey: ["/api/hotels"],
  });

  const { data: packages = [] } = useQuery<Package[]>({
    queryKey: ["/api/packages/featured"],
  });

  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      {/* Hero Section */}
      <section className="travel-gradient text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">Find Your Perfect Trip</h2>
            <p className="text-xl text-blue-100">Compare flights, hotels, and packages from hundreds of travel sites</p>
          </div>
          <SearchTabs />
        </div>
      </section>

      {/* Popular Destinations */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-gray-900 mb-4">Popular Destinations</h3>
            <p className="text-lg text-gray-600">Discover amazing places around the world</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {destinations.map((destination) => (
              <DestinationCard key={destination.id} destination={destination} />
            ))}
          </div>
        </div>
      </section>

      {/* Featured Deals */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-gray-900 mb-4">Featured Deals</h3>
            <p className="text-lg text-gray-600">Limited time offers you can't miss</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
            {/* Flight Deal */}
            <div className="bg-gradient-to-r from-blue-600 to-travel-blue rounded-xl text-white p-8">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h4 className="text-2xl font-bold mb-2">Flight Sale</h4>
                  <p className="text-blue-100">Save up to 40% on international flights</p>
                </div>
                <Plane className="h-12 w-12 text-blue-200" />
              </div>
              <img 
                src="https://images.unsplash.com/photo-1436491865332-7a61a109cc05?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=200" 
                alt="Airplane wing during sunset flight" 
                className="w-full h-32 object-cover rounded-lg mb-4"
              />
              <Button className="bg-white text-travel-blue hover:bg-gray-100 transition-colors">
                Book Now
              </Button>
            </div>

            {/* Hotel Deal */}
            <div className="bg-gradient-to-r from-travel-orange to-red-500 rounded-xl text-white p-8">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h4 className="text-2xl font-bold mb-2">Hotel Deals</h4>
                  <p className="text-orange-100">Free breakfast and WiFi included</p>
                </div>
                <HotelIcon className="h-12 w-12 text-orange-200" />
              </div>
              <img 
                src="https://images.unsplash.com/photo-1566073771259-6a8506099945?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=200" 
                alt="Luxury hotel lobby interior" 
                className="w-full h-32 object-cover rounded-lg mb-4"
              />
              <Button className="bg-white text-travel-orange hover:bg-gray-100 transition-colors">
                View Hotels
              </Button>
            </div>
          </div>

          {/* Vacation Packages */}
          <div>
            <h4 className="text-2xl font-bold text-gray-900 mb-8 text-center">Vacation Packages</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {packages.map((pkg) => (
                <PackageCard key={pkg.id} package={pkg} />
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Top Hotels */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-gray-900 mb-4">Top Hotels</h3>
            <p className="text-lg text-gray-600">Discover comfort and luxury at these amazing properties</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {hotels.slice(0, 6).map((hotel) => (
              <HotelCard key={hotel.id} hotel={hotel} />
            ))}
          </div>
        </div>
      </section>

      {/* Trust Badges */}
      <section className="py-12 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 items-center text-center">
            <div className="flex flex-col items-center">
              <Shield className="h-8 w-8 text-travel-blue mb-2" />
              <span className="text-sm font-medium text-gray-600">Secure Booking</span>
            </div>
            <div className="flex flex-col items-center">
              <Star className="h-8 w-8 text-yellow-400 mb-2" />
              <span className="text-sm font-medium text-gray-600">4.8/5 Rating</span>
            </div>
            <div className="flex flex-col items-center">
              <Headphones className="h-8 w-8 text-travel-blue mb-2" />
              <span className="text-sm font-medium text-gray-600">24/7 Support</span>
            </div>
            <div className="flex flex-col items-center">
              <Users className="h-8 w-8 text-travel-blue mb-2" />
              <span className="text-sm font-medium text-gray-600">5M+ Travelers</span>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-travel-dark text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h4 className="text-xl font-bold mb-4">
                <Plane className="inline mr-2 h-5 w-5" />
                TravelHub
              </h4>
              <p className="text-gray-300 mb-4">Your trusted travel companion for amazing adventures worldwide.</p>
            </div>
            <div>
              <h5 className="font-semibold mb-4">Travel</h5>
              <ul className="space-y-2 text-gray-300">
                <li><a href="/flights" className="hover:text-white">Flights</a></li>
                <li><a href="/hotels" className="hover:text-white">Hotels</a></li>
                <li><a href="/packages" className="hover:text-white">Vacation Packages</a></li>
                <li><a href="/destinations" className="hover:text-white">Destinations</a></li>
              </ul>
            </div>
            <div>
              <h5 className="font-semibold mb-4">Support</h5>
              <ul className="space-y-2 text-gray-300">
                <li><a href="#" className="hover:text-white">Help Center</a></li>
                <li><a href="#" className="hover:text-white">Contact Us</a></li>
                <li><a href="#" className="hover:text-white">Manage Booking</a></li>
                <li><a href="#" className="hover:text-white">Travel Alerts</a></li>
              </ul>
            </div>
            <div>
              <h5 className="font-semibold mb-4">Company</h5>
              <ul className="space-y-2 text-gray-300">
                <li><a href="#" className="hover:text-white">About Us</a></li>
                <li><a href="#" className="hover:text-white">Careers</a></li>
                <li><a href="#" className="hover:text-white">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-white">Terms of Service</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-600 mt-8 pt-8 text-center text-gray-300">
            <p>&copy; 2024 TravelHub. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
