import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import Header from "@/components/header";
import HotelCard from "@/components/hotel-card";
import SearchTabs from "@/components/search-tabs";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Filter, ArrowUpDown } from "lucide-react";
import type { Hotel } from "@shared/schema";

export default function Hotels() {
  const [location] = useLocation();
  const [sortBy, setSortBy] = useState("price");
  
  // Parse search params from URL
  const urlParams = new URLSearchParams(location.split('?')[1] || '');
  const searchParams = {
    location: urlParams.get('location') || '',
    checkin: urlParams.get('checkin') || '',
    checkout: urlParams.get('checkout') || '',
  };

  const { data: hotels = [], isLoading } = useQuery<Hotel[]>({
    queryKey: ["/api/hotels", searchParams.location],
  });

  const sortedHotels = [...hotels].sort((a, b) => {
    switch (sortBy) {
      case "price":
        return parseFloat(a.pricePerNight) - parseFloat(b.pricePerNight);
      case "rating":
        return parseFloat(b.rating) - parseFloat(a.rating);
      case "name":
        return a.name.localeCompare(b.name);
      default:
        return 0;
    }
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-white">
        <Header />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center">Loading hotels...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      {/* Search Section */}
      <section className="bg-gradient-to-r from-travel-blue to-blue-800 text-white py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold mb-6 text-center">Search Hotels</h2>
          <SearchTabs />
        </div>
      </section>

      {/* Results Section */}
      <section className="py-8 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center mb-8">
            <h3 className="text-2xl font-bold text-gray-900">
              Hotel Search Results {searchParams.location && (
                <span className="text-lg font-normal text-gray-600">
                  in {searchParams.location}
                </span>
              )}
            </h3>
            <div className="flex items-center space-x-4">
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-48">
                  <ArrowUpDown className="h-4 w-4 mr-2" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="price">Sort by Price</SelectItem>
                  <SelectItem value="rating">Sort by Rating</SelectItem>
                  <SelectItem value="name">Sort by Name</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline" size="sm">
                <Filter className="h-4 w-4 mr-1" />
                Filters
              </Button>
            </div>
          </div>

          {sortedHotels.length === 0 ? (
            <div className="text-center py-12">
              <h4 className="text-xl font-semibold text-gray-900 mb-2">No hotels found</h4>
              <p className="text-gray-600">Try adjusting your search criteria or browse all available hotels.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {sortedHotels.map((hotel) => (
                <HotelCard key={hotel.id} hotel={hotel} />
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
