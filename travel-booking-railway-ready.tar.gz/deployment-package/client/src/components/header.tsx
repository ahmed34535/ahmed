import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Plane, Globe, Menu } from "lucide-react";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

export default function Header() {
  const [location] = useLocation();

  const navItems = [
    { href: "/flights", label: "Flights" },
    { href: "/hotels", label: "Hotels" },
    { href: "/packages", label: "Packages" },
    { href: "/destinations", label: "Destinations" },
  ];

  const isActive = (href: string) => location === href;

  return (
    <header className="bg-white shadow-sm border-b">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <Link href="/">
                <h1 className="text-2xl font-bold text-travel-blue cursor-pointer">
                  <Plane className="inline mr-2 h-6 w-6" />
                  TravelHub
                </h1>
              </Link>
            </div>
            <nav className="hidden md:block ml-10">
              <div className="flex items-baseline space-x-8">
                {navItems.map((item) => (
                  <Link key={item.href} href={item.href}>
                    <span
                      className={`px-3 py-2 text-sm font-medium transition-colors cursor-pointer ${
                        isActive(item.href)
                          ? "text-travel-blue"
                          : "text-travel-dark hover:text-travel-blue"
                      }`}
                    >
                      {item.label}
                    </span>
                  </Link>
                ))}
              </div>
            </nav>
          </div>
          
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" className="hidden md:flex">
              <Globe className="h-4 w-4 mr-1" />
              USD
            </Button>
            <Button variant="ghost" size="sm">
              Sign In
            </Button>
            <Button size="sm" className="bg-travel-blue hover:bg-blue-700">
              Sign Up
            </Button>
            
            {/* Mobile menu */}
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="sm" className="md:hidden">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right">
                <nav className="flex flex-col space-y-4 mt-8">
                  {navItems.map((item) => (
                    <Link key={item.href} href={item.href}>
                      <span
                        className={`text-sm font-medium cursor-pointer ${
                          isActive(item.href)
                            ? "text-travel-blue"
                            : "text-travel-dark hover:text-travel-blue"
                        }`}
                      >
                        {item.label}
                      </span>
                    </Link>
                  ))}
                </nav>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </header>
  );
}
