import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { formatPrice } from "@/lib/utils";
import type { Destination } from "@shared/schema";

interface DestinationCardProps {
  destination: Destination;
  onClick?: () => void;
}

export default function DestinationCard({ destination, onClick }: DestinationCardProps) {
  return (
    <Card className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow cursor-pointer" onClick={onClick}>
      <img 
        src={destination.imageUrl} 
        alt={destination.name}
        className="w-full h-48 object-cover"
      />
      <CardContent className="p-6">
        <h4 className="text-xl font-semibold text-gray-900 mb-2">{destination.name}</h4>
        <p className="text-gray-600 mb-4">{destination.description}</p>
        <div className="flex justify-between items-center">
          <span className="text-travel-blue font-semibold">
            From {formatPrice(destination.priceFrom)}
          </span>
          <Button variant="ghost" className="text-travel-blue hover:text-blue-700 font-medium p-0">
            Explore →
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
