import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plane } from "lucide-react";
import { formatPrice } from "@/lib/utils";
import type { Flight } from "@shared/schema";

interface FlightCardProps {
  flight: Flight;
  onClick?: () => void;
}

export default function FlightCard({ flight, onClick }: FlightCardProps) {
  return (
    <Card className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow" onClick={onClick}>
      <CardContent className="p-6">
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-8">
            <div className="text-center">
              <div className="text-lg font-semibold text-gray-900">{flight.departureTime}</div>
              <div className="text-sm text-gray-500">{flight.departureAirport}</div>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-8 h-px bg-gray-300"></div>
              <Plane className="h-5 w-5 text-travel-blue" />
              {flight.stops > 0 && (
                <>
                  <div className="w-6 h-px bg-gray-300"></div>
                  <Plane className="h-5 w-5 text-travel-blue" />
                </>
              )}
              <div className="w-8 h-px bg-gray-300"></div>
            </div>
            <div className="text-center">
              <div className="text-lg font-semibold text-gray-900">{flight.arrivalTime}</div>
              <div className="text-sm text-gray-500">{flight.arrivalAirport}</div>
            </div>
            <div className="text-sm text-gray-500">
              <div>{flight.duration}</div>
              <div>{flight.stops === 0 ? 'Direct' : `${flight.stops} stop${flight.stops > 1 ? 's' : ''}`}</div>
            </div>
          </div>
          <div className="text-right">
            <div className="text-2xl font-bold text-travel-blue">{formatPrice(flight.price)}</div>
            <div className="text-sm text-gray-500 mb-2">{flight.airline} {flight.flightNumber}</div>
            <Button className="bg-travel-orange text-white hover:bg-orange-600 transition-colors">
              Select
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
