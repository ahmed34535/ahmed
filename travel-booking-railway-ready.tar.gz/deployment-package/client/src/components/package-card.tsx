import { Card, CardContent } from "@/components/ui/card";
import { Star } from "lucide-react";
import { formatPrice, formatRating, generateStars } from "@/lib/utils";
import type { Package } from "@shared/schema";

interface PackageCardProps {
  package: Package;
  onClick?: () => void;
}

export default function PackageCard({ package: pkg, onClick }: PackageCardProps) {
  const rating = formatRating(pkg.rating);
  const { fullStars, hasHalfStar, emptyStars } = generateStars(rating);

  return (
    <Card className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow cursor-pointer" onClick={onClick}>
      <img 
        src={pkg.imageUrl} 
        alt={pkg.name}
        className="w-full h-40 object-cover"
      />
      <CardContent className="p-4">
        <h5 className="font-semibold text-gray-900 mb-1">{pkg.name}</h5>
        <p className="text-sm text-gray-600 mb-2">{pkg.duration}, {pkg.destination}</p>
        <div className="flex justify-between items-center">
          <span className="text-travel-blue font-bold">{formatPrice(pkg.price)}</span>
          <div className="flex items-center">
            <div className="flex text-yellow-400 text-xs mr-1">
              {Array.from({ length: fullStars }, (_, i) => (
                <Star key={i} className="h-3 w-3 fill-current" />
              ))}
              {hasHalfStar && <Star className="h-3 w-3 fill-current opacity-50" />}
              {Array.from({ length: emptyStars }, (_, i) => (
                <Star key={i + fullStars} className="h-3 w-3 text-gray-300" />
              ))}
            </div>
            <span className="text-xs text-gray-500">{rating}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
