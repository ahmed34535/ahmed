import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Star } from "lucide-react";
import { formatPrice, formatRating, generateStars } from "@/lib/utils";
import type { Hotel } from "@shared/schema";

interface HotelCardProps {
  hotel: Hotel;
  onClick?: () => void;
}

export default function HotelCard({ hotel, onClick }: HotelCardProps) {
  const rating = formatRating(hotel.rating);
  const { fullStars, hasHalfStar, emptyStars } = generateStars(rating);

  return (
    <Card className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow" onClick={onClick}>
      <img 
        src={hotel.imageUrl} 
        alt={hotel.name}
        className="w-full h-48 object-cover"
      />
      <CardContent className="p-6">
        <div className="flex justify-between items-start mb-2">
          <h4 className="text-xl font-semibold text-gray-900">{hotel.name}</h4>
          <div className="flex items-center">
            <div className="flex text-yellow-400 text-sm mr-1">
              {Array.from({ length: fullStars }, (_, i) => (
                <Star key={i} className="h-4 w-4 fill-current" />
              ))}
              {hasHalfStar && <Star className="h-4 w-4 fill-current opacity-50" />}
              {Array.from({ length: emptyStars }, (_, i) => (
                <Star key={i + fullStars} className="h-4 w-4 text-gray-300" />
              ))}
            </div>
            <span className="text-sm text-gray-500">{rating}</span>
          </div>
        </div>
        <p className="text-gray-600 mb-4">{hotel.location} • {hotel.distanceFromCenter}</p>
        <div className="flex justify-between items-center">
          <div>
            <span className="text-2xl font-bold text-travel-blue">{formatPrice(hotel.pricePerNight)}</span>
            <span className="text-gray-500">/night</span>
          </div>
          <Button className="bg-travel-blue text-white hover:bg-blue-700 transition-colors">
            View Deal
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
