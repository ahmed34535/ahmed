# Travel Booking Application - Railway Deployment

## Quick Start
1. Upload all files from this package to your GitHub repository
2. Connect repository to Railway
3. Add DATABASE_URL environment variable
4. Deploy automatically

## Project Structure
- **package.json** - Node.js configuration and scripts
- **client/** - React frontend (361KB build)
- **server/** - Express backend (14KB build)
- **shared/** - TypeScript schemas
- **dist/** - Production build artifacts
- **Configuration files** - Railway and build settings

## Environment Variable Required
```
DATABASE_URL=postgresql://neondb_owner:[password]@ep-tiny-sky-a5ae7lq2.us-east-2.aws.neon.tech:5432/neondb
```

## Expected Build Process
- Build Command: `npm run build`
- Start Command: `npm start`
- Node.js Version: 20.x
- Build Time: ~3-4 minutes

Your travel booking application with destinations, hotels, flights, and packages will be live after deployment.